import concurrent.futures as cf,json,os,pathlib,subprocess,sys,time
phase=sys.argv[1]; out=pathlib.Path('/tmp/h3-'+phase);out.mkdir(exist_ok=True)
# All subprocesses are owned, foreground, and joined. No retries.
burners=[subprocess.Popen([sys.executable,'-c','while True: pass']) for _ in range(15)]
tests=[('core','custody_restore::git_tests::b2b_no_effect_follows_a_guard_that_finds_the_deadline_spent')]
env=dict(os.environ,A2A_LANE_GIT='/opt/git/bin/git',PATH='/opt/git/bin:'+os.environ['PATH'])
def run(kind,name,i):
 t=time.monotonic();p=subprocess.run(['/tmp/h3-base-'+kind,'--exact',name,'--nocapture'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
 (out/(name.rsplit('::',1)[-1]+f'-{i}.log')).write_bytes(p.stdout)
 return dict(test=name,run=i,exit=p.returncode,seconds=time.monotonic()-t)
try:
 for kind,name in tests:
  if (out/(name.rsplit('::',1)[-1]+'.json')).exists(): continue
  with cf.ThreadPoolExecutor(max_workers=50) as pool: rows=list(pool.map(lambda i:run(kind,name,i),range(50)))
  (out/(name.rsplit('::',1)[-1]+'.json')).write_text(json.dumps(rows,indent=2))
  print(name, sum(r['exit']!=0 for r in rows),'/50', 'max',round(max(r['seconds'] for r in rows),3),flush=True)
finally:
 for p in burners:p.terminate()
 for p in burners:p.wait()
